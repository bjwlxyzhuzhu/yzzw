# 数据字典（schema 3.0）

所有时间为 ISO 8601 UTC，服务端时钟（composer_opened_at 来自浏览器时钟并由服务端校验格式）。ID 为随机标识；外键：events.run_id→runs，events.reply_to→events，scheduler_decisions.run_id→runs，artifacts.parent_id→artifacts，transfers.*_artifact_id→artifacts，ratings.target_id→events/artifacts。

| 表 | 字段 | 口径与边界 |
|---|---|---|
| runs | wall_duration_ms | 开始至结束墙钟时间，包含暂停与等待，不等于学习投入 |
| runs | paused_ms / active_session_ms | 暂停累计；active = wall − paused |
| runs | model_calls | 成功的真实模型调用数（演示模式为 0） |
| runs | config | 运行配置快照（含随机 seed、互动自由度等） |
| events | sequence / elapsed_ms / inter_event_ms | 同一运行内序号；距开始毫秒；与上一事件间隔（不是思考时间） |
| events | reply_to / reply_latency_ms | 被回应事件；回应间隔（不代表推理时间） |
| events | composer_opened_at / submitted_at / input_dwell_ms | 真人打开输入框至提交；输入框停留不是思考时长 |
| events | source / data_provenance | demo/model/human_input/system 与其研究含义 |
| events | decision_id | 对应的调度决策（课堂） |
| scheduler_decisions | trigger / n_eligible / speak_probability / draw | 参与机会的触发类型、合格候选数、发言概率、随机抽样值（draw < p 则有人发言） |
| scheduler_decisions | hands / selected_agent / action / top_weights | 举手意图（≤3）、选中者、动作、前 8 名权重；只记录可追踪的选择依据，不保存或要求模型思维链 |
| scheduler_decisions | distribution_version | 调度分布算法版本 |
| interaction_edges | edge_type | reply_to（回应某事件）或 addressed（指向某角色） |
| challenges | human_resolution | 教师人工标记；有回复不等于有效解决 |
| timing_spans | model_call | request_at→completed_at、first_token_at、token 数、request_id，仅记录真实返回值，未知为空 |
| artifacts / artifact_sections | version / parent_id / author / revision | 版本不可覆盖；段落作者与修订次数 |
| transfers | idempotency_key / confirmed_by | 箭头流转的幂等键与确认教师（假名） |
| ratings | score / score_status | 0—4 分；not_rated/not_applicable/insufficient_evidence 不是 0；supersedes_rating_id 为重评链 |
| metrics | is_real_student_learning_time | 恒为 false |

旧字段缺失保留为空，不用当前时间倒填。
